#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Plan A v1 (KERMT TLC) 21 维特征：与 KERMT/tlc/scripts/build_features.py 对齐。

顺序：5 溶剂比例 (H, EA, DCM, MeOH, Et2O) + 10 交叉项 + 6 描述符 (z-score)。

描述符 z-score 的 mean/std 与 build_features 一致：在 SRC_DATA_DIR/train_data.csv 上
按训练脚本方式统计后 6 维，再用于任意新样本。
"""
from __future__ import annotations

import csv
import os
import re
from itertools import combinations
from pathlib import Path
from typing import Optional, Tuple

import numpy as np

SOLVENT_COLS = ["H", "EA", "DCM", "MeOH", "Et2O"]
DESC_COLS = ["MW", "TPSA", "LogP", "HBD", "HBA", "NROTBs"]
CROSS_PAIRS = list(combinations(SOLVENT_COLS, 2))

_RATIO_RE = re.compile(r"^\s*(\d+(?:\.\d+)?)\s*:\s*(\d+(?:\.\d+)?)\s*$")


def parse_ratio_column(colname: str) -> Optional[Tuple[float, float, float]]:
    """列名 'a:b' -> (a, b, f=b/(a+b))，与 optimize_tlc._parse_ratio_col 一致。"""
    m = _RATIO_RE.match(str(colname).strip())
    if not m:
        return None
    a = float(m.group(1))
    b = float(m.group(2))
    s = a + b
    if s <= 0:
        return None
    return a, b, b / s


def compute_desc_stats_from_train_csv(src_dir: str) -> Tuple[np.ndarray, np.ndarray]:
    """与 build_features.py 相同：用 train_data.csv 统计后 6 维 mean/std。"""
    path = os.path.join(src_dir, "train_data.csv")
    rows = []
    with open(path, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            smi = (row.get("COMPOUND_SMILES") or "").strip()
            if not smi:
                continue
            solvent = [float(row.get(c, 0) or 0) for c in SOLVENT_COLS]
            cross = [
                solvent[SOLVENT_COLS.index(a)] * solvent[SOLVENT_COLS.index(b)]
                for a, b in CROSS_PAIRS
            ]
            desc = [float(row.get(c, 0) or 0) for c in DESC_COLS]
            rows.append(solvent + cross + desc)
    features = np.asarray(rows, dtype=np.float64)
    desc_start = len(SOLVENT_COLS) + len(CROSS_PAIRS)
    desc_block = features[:, desc_start:]
    mean = desc_block.mean(axis=0)
    std = desc_block.std(axis=0)
    std = np.where(std < 1e-8, 1.0, std)
    return mean.astype(np.float32), std.astype(np.float32)


def load_or_compute_desc_stats(
    src_data_dir: str,
    cache_path: Optional[Path] = None,
) -> Tuple[np.ndarray, np.ndarray]:
    if cache_path is not None and cache_path.is_file():
        z = np.load(cache_path)
        return z["mean"].astype(np.float32), z["std"].astype(np.float32)
    mean, std = compute_desc_stats_from_train_csv(src_data_dir)
    if cache_path is not None:
        cache_path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(cache_path, mean=mean, std=std)
    return mean, std


def rdkit_descriptor_raw(smiles: str) -> np.ndarray:
    """与训练 CSV 列名一致的 6 维（RDKit 计算）。"""
    from rdkit import Chem
    from rdkit.Chem import Descriptors, Lipinski

    mol = Chem.MolFromSmiles(smiles)
    if mol is None or mol.GetNumHeavyAtoms() == 0:
        raise ValueError(f"Invalid SMILES: {smiles!r}")
    vec = np.array(
        [
            Descriptors.MolWt(mol),
            Descriptors.TPSA(mol),
            Descriptors.MolLogP(mol),
            float(Lipinski.NumHDonors(mol)),
            float(Lipinski.NumHAcceptors(mol)),
            float(Descriptors.NumRotatableBonds(mol)),
        ],
        dtype=np.float32,
    )
    return vec


def solvent_vector_pe_ea(ea_fraction: float) -> np.ndarray:
    """PE/EA：H=PE，极性端为 EA。ea_fraction in [0,1]。"""
    f = float(ea_fraction)
    arr = np.zeros(5, dtype=np.float32)
    arr[0] = 1.0 - f
    arr[1] = f
    return arr


def solvent_vector_dcm_meoh(meoh_fraction: float) -> np.ndarray:
    """DCM/MeOH：MeOH 为极性端。"""
    f = float(meoh_fraction)
    arr = np.zeros(5, dtype=np.float32)
    arr[2] = 1.0 - f
    arr[3] = f
    return arr


def build_21d_row(
    smiles: str,
    solvent_system: str,
    polar_fraction: float,
    desc_mean: np.ndarray,
    desc_std: np.ndarray,
) -> np.ndarray:
    """
    :param solvent_system: 'pe_ea' 或 'dcm_meoh'
    :param polar_fraction: PE/EA 中为 EA 的体积分数 b/(a+b)；DCM/MeOH 中为 MeOH 分数
    """
    sys_key = solvent_system.strip().lower().replace("-", "_")
    if sys_key in ("pe_ea", "h_ea", "pe/ea"):
        s5 = solvent_vector_pe_ea(polar_fraction)
    elif sys_key in ("dcm_meoh", "dcm/meoh"):
        s5 = solvent_vector_dcm_meoh(polar_fraction)
    else:
        raise ValueError(
            f"Unknown solvent_system={solvent_system!r}; use pe_ea or dcm_meoh"
        )
    cross = np.array(
        [s5[SOLVENT_COLS.index(a)] * s5[SOLVENT_COLS.index(b)] for a, b in CROSS_PAIRS],
        dtype=np.float32,
    )
    desc_raw = rdkit_descriptor_raw(smiles)
    desc_z = (desc_raw - desc_mean) / desc_std
    row = np.concatenate([s5, cross, desc_z]).astype(np.float32)
    assert row.shape == (21,)
    return row


def build_features_matrix(
    smiles_list: list[str],
    polar_fractions: list[float],
    solvent_system: str,
    desc_mean: np.ndarray,
    desc_std: np.ndarray,
) -> np.ndarray:
    rows = [
        build_21d_row(s, solvent_system, f, desc_mean, desc_std)
        for s, f in zip(smiles_list, polar_fractions)
    ]
    return np.stack(rows, axis=0)


def default_src_data_dir() -> str:
    return os.environ.get(
        "SRC_DATA_DIR",
        "/root/autodl-tmp/taoyuzhou/unimol_tlc/"
        "merged_data_molecule_split_v2_rf_stratified_heavy70_descriptor",
    )


def default_desc_stats_cache(script_dir: Path) -> Path:
    return script_dir / "data" / "kermt_plan_a_v1_desc_stats.npz"
