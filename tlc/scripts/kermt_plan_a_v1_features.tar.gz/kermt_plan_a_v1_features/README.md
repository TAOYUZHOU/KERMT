# kermt_plan_a_v1_features

Plan A v1 外推预测小工具（21 维手工特征 + `with_features_v1_dirty_finetune5ep` checkpoint）。

## 内容

- `features.py`：21 维特征构造、比例列解析、`train_data.csv` 上描述符 z-score（可缓存）。与 `c12_TLC_Predictor/optimize_script/kermt_plan_a_v1_features.py` 同步。
- `kermt_plan_a_v1_predictor.py`：进程内 CUDA 常驻推理（与 optimize_script 同步）；`KERMT_PLAN_A_V1_USE_SUBPROCESS=1` 可强制子进程 `main.py predict`。
- `predict_rf_kermt_plan_a_v1.py`：`single` / `eval-excels` 子命令（内部缓存 `KermtPlanAV1Predictor`，多表评测不反复加载权重）。
- `data/`：示例 Excel（leyan / medisilion）与 `kermt_plan_a_v1_desc_stats.npz`（描述符 mean/std 缓存）。

原版来自 `c12_TLC_Predictor/optimize_script/`，此处副本便于在 KERMT 仓库内运行。

## 运行

在 KERMT 仓库根目录：

```bash
export CUBLAS_WORKSPACE_CONFIG=:4096:8   # GPU 时需要

python tlc/scripts/kermt_plan_a_v1_features/predict_rf_kermt_plan_a_v1.py single \
  --smiles "CCO" --system pe_ea --fraction 0.35

python tlc/scripts/kermt_plan_a_v1_features/predict_rf_kermt_plan_a_v1.py eval-excels
```

- 默认 `--kermt_root` 由本脚本路径自动推断（`.../tlc/scripts/kermt_plan_a_v1_features/` → 上三级为 KERMT 根）。
- 若合并数据不在默认路径，设置环境变量 `SRC_DATA_DIR`（含 `train_data.csv`）或传 `--src_data_dir`。

## 依赖

与 KERMT 微调相同：PyTorch、RDKit、pandas、openpyxl、matplotlib、scikit-learn。

## 分发包

在 `KERMT/tlc/scripts/` 下更新归档：

```bash
cd /path/to/KERMT/tlc/scripts
tar -czvf kermt_plan_a_v1_features.tar.gz kermt_plan_a_v1_features/
```

生成文件：`tlc/scripts/kermt_plan_a_v1_features.tar.gz`
