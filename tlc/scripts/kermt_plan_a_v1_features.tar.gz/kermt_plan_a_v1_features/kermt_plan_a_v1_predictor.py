#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
KERMT Plan A v1 预测封装：与 optimize_script 中 optimize_tlc 所用版本一致。

默认在 **同一 Python 进程内** 将权重加载到 CUDA 并 **常驻显存**，多次 predict 只跑前向，避免反复子进程重启。
可通过环境变量 ``KERMT_PLAN_A_V1_USE_SUBPROCESS=1`` 强制走旧版子进程（与 main.py 完全一致）。

本包内特征模块文件名为 ``features.py``，故从此处 ``from features import ...``。
"""
from __future__ import annotations

import logging
import os
import subprocess
import sys
import tempfile
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from features import (
    build_features_matrix,
    default_desc_stats_cache,
    default_src_data_dir,
    load_or_compute_desc_stats,
)

SOLVENT_TO_IDX = {"H": 0, "EA": 1, "DCM": 2, "MeOH": 3, "Et2O": 4}


def _solvent_system_key(solvent1: str, solvent2: str) -> str:
    s1, s2 = str(solvent1).strip(), str(solvent2).strip()
    if s1 == "H" and s2 == "EA":
        return "pe_ea"
    if s1 == "DCM" and s2 == "MeOH":
        return "dcm_meoh"
    raise ValueError(
        f"KERMT Plan A v1 当前仅支持 solvent_system H,EA 或 DCM,MeOH；"
        f"收到 {s1},{s2}"
    )


def _polar_fraction_from_arr(solvent5, solvent1: str, solvent2: str) -> float:
    arr = np.asarray(solvent5, dtype=np.float64).reshape(-1)
    if arr.size != 5:
        raise ValueError("solvent vector must be length 5")
    i1 = SOLVENT_TO_IDX[solvent1]
    i2 = SOLVENT_TO_IDX[solvent2]
    d = float(arr[i1] + arr[i2])
    if d <= 1e-12:
        return 0.0
    return float(arr[i2] / d)


def _env_truthy(name: str) -> bool:
    return os.environ.get(name, "").strip().lower() in ("1", "true", "yes", "on")


class KermtPlanAV1Predictor:
    """
    默认：进程内 CUDA 常驻模型 + task.predict.predict 前向。
    备选：子进程 ``main.py predict``（``KERMT_PLAN_A_V1_USE_SUBPROCESS=1`` 或 CUDA 不可用且未强制仅 CUDA 时）。
    std 返回常数 min_std（无原生不确定性）。
    """

    def __init__(
        self,
        *,
        kermt_root: str | Path,
        checkpoint_dir: str | Path,
        desc_stats_cache: str | Path | None = None,
        src_data_dir: str | None = None,
        solvent1: str = "H",
        solvent2: str = "EA",
        min_std: float = 0.02,
        script_dir: str | Path | None = None,
        gpu: int | None = None,
        batch_size: int = 64,
        use_subprocess: bool | None = None,
    ):
        self.kermt_root = Path(kermt_root).expanduser().resolve()
        self.checkpoint_dir = Path(checkpoint_dir).expanduser().resolve()
        if not self.checkpoint_dir.is_dir():
            raise FileNotFoundError(f"kermt checkpoint_dir not found: {self.checkpoint_dir}")
        pt = self.checkpoint_dir / "model.pt"
        if not pt.is_file():
            raise FileNotFoundError(f"model.pt missing under {self.checkpoint_dir}")

        sd = Path(script_dir).expanduser().resolve() if script_dir else Path(__file__).resolve().parent
        cache = (
            Path(desc_stats_cache).expanduser().resolve()
            if desc_stats_cache
            else default_desc_stats_cache(sd)
        )
        src = src_data_dir or default_src_data_dir()
        self.mean, self.std = load_or_compute_desc_stats(src, cache_path=cache)

        self.solvent1 = str(solvent1).strip()
        self.solvent2 = str(solvent2).strip()
        self._system = _solvent_system_key(self.solvent1, self.solvent2)
        self.min_std = float(max(1e-6, min_std))

        if gpu is None:
            gpu = int(os.environ.get("KERMT_PLAN_A_V1_GPU", "0"))
        self._gpu = int(gpu)
        self._batch_size = int(batch_size)
        # None => 自动；True => 总用子进程；False => 优先 CUDA，失败再子进程
        self._use_subprocess_override = use_subprocess

        self._cuda_model = None
        self._pred_args = None
        self._train_args = None
        self._scaler = None
        self._features_scaler = None
        self._logger: logging.Logger | None = None
        self._shared_dict: dict | None = None
        self._kermt_predict = None

    def _ensure_kermt_on_path(self) -> None:
        root = str(self.kermt_root)
        if root not in sys.path:
            sys.path.insert(0, root)

    def _want_subprocess(self) -> bool:
        if self._use_subprocess_override is True:
            return True
        if self._use_subprocess_override is False:
            return False
        return _env_truthy("KERMT_PLAN_A_V1_USE_SUBPROCESS")

    def _cuda_available(self) -> bool:
        try:
            import torch

            return bool(torch.cuda.is_available())
        except Exception:
            return False

    def _lazy_init_cuda(self) -> None:
        if self._cuda_model is not None:
            return
        self._ensure_kermt_on_path()
        import torch
        from argparse import Namespace

        from kermt.util.utils import create_logger, load_args, load_checkpoint_for_prediction, load_scalars
        from task.predict import predict as kermt_predict

        pt = str((self.checkpoint_dir / "model.pt").resolve())
        scaler, features_scaler = load_scalars(pt)
        train_args = load_args(pt)
        pred_args = Namespace()
        for key, value in vars(train_args).items():
            setattr(pred_args, key, value)
        pred_args.checkpoint_paths = [pt]
        pred_args.gpu = self._gpu
        pred_args.batch_size = self._batch_size
        pred_args.cuda = True
        if torch.cuda.is_available():
            torch.cuda.set_device(self._gpu)

        logger = create_logger(f"kermt_pd_{id(self)}", quiet=True)
        model = load_checkpoint_for_prediction(pt, current_args=pred_args, cuda=True, logger=logger)
        model.eval()

        self._cuda_model = model
        self._pred_args = pred_args
        self._train_args = train_args
        self._scaler = scaler
        self._features_scaler = features_scaler
        self._logger = logger
        self._shared_dict = {}
        self._kermt_predict = kermt_predict

    def _run_predict_subprocess(self, smiles_list: list[str], X: np.ndarray) -> np.ndarray:
        env = os.environ.copy()
        env.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
        with tempfile.TemporaryDirectory(prefix="kermt_bo_") as td:
            td = Path(td)
            csv_p = td / "in.csv"
            npz_p = td / "feats.npz"
            out_p = td / "out.csv"
            with open(csv_p, "w", encoding="utf-8") as f:
                f.write("smiles,Rf\n")
                for s in smiles_list:
                    f.write(f'"{s.replace(chr(34), chr(34)+chr(34))}",0.0\n')
            np.savez_compressed(npz_p, features=np.asarray(X, dtype=np.float32))
            cmd = [
                sys.executable,
                str(self.kermt_root / "main.py"),
                "predict",
                "--data_path",
                str(csv_p.resolve()),
                "--features_path",
                str(npz_p.resolve()),
                "--checkpoint_dir",
                str(self.checkpoint_dir.resolve()),
                "--output_path",
                str(out_p.resolve()),
                "--gpu",
                str(self._gpu),
                "--batch_size",
                str(self._batch_size),
            ]
            subprocess.run(cmd, cwd=str(self.kermt_root), env=env, check=True)
            pred_df = pd.read_csv(out_p)
            if "Rf" not in pred_df.columns or len(pred_df) != len(smiles_list):
                raise RuntimeError(f"KERMT predict output mismatch: {pred_df.head()}")
            return pred_df["Rf"].values.astype(np.float64)

    def _run_predict_cuda(self, smiles_list: list[str], X: np.ndarray) -> np.ndarray:
        self._lazy_init_cuda()
        from kermt.data import MoleculeDatapoint, MoleculeDataset

        X = np.asarray(X, dtype=np.float64)
        if X.shape[0] != len(smiles_list):
            raise ValueError("smiles_list length must match X.shape[0]")
        assert self._pred_args is not None and self._cuda_model is not None
        assert self._kermt_predict is not None and self._shared_dict is not None

        dps = []
        for i, s in enumerate(smiles_list):
            row = [str(s), "0.0"]
            feat = np.asarray(X[i], dtype=np.float64).reshape(-1)
            dps.append(MoleculeDatapoint(line=row, args=self._pred_args, features=feat))
        test_data = MoleculeDataset(dps)
        if hasattr(self._train_args, "features_scaling") and self._train_args.features_scaling:
            test_data.normalize_features(self._features_scaler)

        preds, _ = self._kermt_predict(
            model=self._cuda_model,
            data=test_data,
            args=self._pred_args,
            batch_size=self._batch_size,
            loss_func=None,
            logger=self._logger,
            shared_dict=self._shared_dict,
            scaler=self._scaler,
        )
        arr = np.asarray(preds, dtype=np.float64).reshape(-1)
        if arr.size != len(smiles_list):
            raise RuntimeError(
                f"KERMT CUDA predict length mismatch: got {arr.size}, expected {len(smiles_list)}"
            )
        return arr

    def _run_predict(self, smiles_list: list[str], X: np.ndarray) -> np.ndarray:
        if self._want_subprocess():
            return self._run_predict_subprocess(smiles_list, X)
        if not self._cuda_available():
            return self._run_predict_subprocess(smiles_list, X)
        try:
            return self._run_predict_cuda(smiles_list, X)
        except Exception as e:
            warnings.warn(
                f"KERMT persistent CUDA inference failed ({type(e).__name__}: {e}); "
                "falling back to subprocess once.",
                RuntimeWarning,
                stacklevel=2,
            )
            return self._run_predict_subprocess(smiles_list, X)

    def predict_batch(self, smiles: str, solvent_arrs: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        """与 UniMolPredictor / GAT5FoldPredictor 相同签名。"""
        arrs = np.asarray(solvent_arrs, dtype=np.float32)
        if arrs.ndim == 1:
            arrs = arrs.reshape(1, -1)
        n = arrs.shape[0]
        smiles_list = [str(smiles)] * n
        fracs = [_polar_fraction_from_arr(arrs[i], self.solvent1, self.solvent2) for i in range(n)]
        X = build_features_matrix(smiles_list, fracs, self._system, self.mean, self.std)
        mu = self._run_predict(smiles_list, X)
        sig = np.full_like(mu, self.min_std, dtype=np.float64)
        return mu, sig

    def predict_points_list(self, points: list[dict]) -> np.ndarray:
        """points: 每项含 smiles, solvent(list 长度5)。顺序与输出一致。"""
        if not points:
            return np.array([], dtype=np.float64)
        smiles_list = [str(p["smiles"]) for p in points]
        fracs = [
            _polar_fraction_from_arr(p["solvent"], self.solvent1, self.solvent2) for p in points
        ]
        X = build_features_matrix(smiles_list, fracs, self._system, self.mean, self.std)
        return self._run_predict(smiles_list, X)
