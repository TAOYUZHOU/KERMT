#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
KERMT Plan A v1（with_features_v1_dirty_finetune5ep）推理与 Excel 评测。

本目录为自包含包：含 `features.py`、`kermt_plan_a_v1_predictor.py`（与 c12 optimize_script 同步，默认 CUDA 常驻）、示例 Excel 与描述符统计缓存。

默认 KERMT 根目录：本文件位于 .../KERMT/tlc/scripts/kermt_plan_a_v1_features/，
自动解析为 parents[3] -> KERMT 仓库根。

用法（在 KERMT 仓库根或任意目录）：
  export CUBLAS_WORKSPACE_CONFIG=:4096:8   # GPU + deterministic 时需要

  python tlc/scripts/kermt_plan_a_v1_features/predict_rf_kermt_plan_a_v1.py single \\
    --smiles "CCO" --system pe_ea --fraction 0.35

  python tlc/scripts/kermt_plan_a_v1_features/predict_rf_kermt_plan_a_v1.py eval-excels
"""
from __future__ import annotations

import argparse
import os
import subprocess
import sys
from pathlib import Path

import numpy as np
import pandas as pd

# 同目录模块
_PKG_DIR = Path(__file__).resolve().parent
if str(_PKG_DIR) not in sys.path:
    sys.path.insert(0, str(_PKG_DIR))

from features import (
    default_desc_stats_cache,
    default_src_data_dir,
    parse_ratio_column,
)
from kermt_plan_a_v1_predictor import KermtPlanAV1Predictor

# 按 (root, ckpt, 溶剂体系, 描述符缓存, src_data, gpu, batch) 缓存预测器，避免 eval 多表时重复加载权重
_PREDICTORS: dict[tuple[str, ...], KermtPlanAV1Predictor] = {}


def _predictor_keyed(
    kermt_root: Path,
    checkpoint_dir: Path,
    solvent_system: str,
    src_data_dir: str,
    desc_stats_cache: Path,
    gpu: int,
    batch_size: int,
) -> KermtPlanAV1Predictor:
    key = (
        str(kermt_root.resolve()),
        str(checkpoint_dir.resolve()),
        solvent_system,
        str(Path(desc_stats_cache).resolve()),
        str(Path(src_data_dir).resolve()) if src_data_dir else "",
        str(int(gpu)),
        str(int(batch_size)),
    )
    if key not in _PREDICTORS:
        s1, s2 = (
            ("H", "EA")
            if solvent_system == "pe_ea"
            else ("DCM", "MeOH")
            if solvent_system == "dcm_meoh"
            else (None, None)
        )
        if s1 is None:
            raise ValueError(f"Unknown solvent_system={solvent_system!r}")
        _PREDICTORS[key] = KermtPlanAV1Predictor(
            kermt_root=kermt_root,
            checkpoint_dir=checkpoint_dir,
            desc_stats_cache=desc_stats_cache,
            src_data_dir=src_data_dir or None,
            solvent1=s1,
            solvent2=s2,
            script_dir=_PKG_DIR,
            gpu=int(gpu),
            batch_size=int(batch_size),
        )
    return _PREDICTORS[key]


def _five_vec_from_fraction(frac: float, system: str) -> list[float]:
    """强极性占比 f -> [H,EA,DCM,MeOH,Et2O]。"""
    f = max(0.0, min(1.0, float(frac)))
    v = [0.0, 0.0, 0.0, 0.0, 0.0]
    if system == "pe_ea":
        v[0] = 1.0 - f
        v[1] = f
    elif system == "dcm_meoh":
        v[2] = 1.0 - f
        v[3] = f
    else:
        raise ValueError(system)
    return v

DEFAULT_KERMT_ROOT = Path(
    os.environ.get("KERMT_ROOT", str(Path(__file__).resolve().parents[3]))
)
DEFAULT_CKPT_DIR = DEFAULT_KERMT_ROOT / (
    "tlc/results/with_features_v1_dirty_finetune5ep/fold_0/model_0"
)

DEFAULT_EXCEL_FILES = [
    _PKG_DIR / "data/leyan_dcm_meoh.xlsx",
    _PKG_DIR / "data/leyan_pe_ea.xlsx",
    _PKG_DIR / "data/medisilion_dcm_meoh.xlsx",
    _PKG_DIR / "data/medisilion_pe_ea.xlsx",
]


def _system_from_filename(path: Path) -> str:
    name = path.stem.lower()
    if "dcm_meoh" in name or "dcm-meoh" in name:
        return "dcm_meoh"
    if "pe_ea" in name or "pe-ea" in name:
        return "pe_ea"
    raise ValueError(
        f"Cannot infer solvent system from {path.name}; "
        "expected filename containing 'pe_ea' or 'dcm_meoh'."
    )


def _smiles_column(df: pd.DataFrame) -> str:
    if "SMILES" in df.columns:
        return "SMILES"
    for c in df.columns:
        if str(c).upper() == "SMILES":
            return c
    raise ValueError("No SMILES column found in dataframe.")


def _smiles_ok_for_rdkit(smiles: str) -> bool:
    from rdkit import Chem

    mol = Chem.MolFromSmiles(smiles)
    return mol is not None and mol.GetNumHeavyAtoms() > 0


def excel_long_table(df: pd.DataFrame, solvent_system: str) -> pd.DataFrame:
    """宽表 -> 长表：smiles, polar_fraction, rf_obs, ratio_label."""
    smi_col = _smiles_column(df)
    ratio_cols = [c for c in df.columns if parse_ratio_column(c) is not None]
    if not ratio_cols:
        raise ValueError("No a:b ratio columns found.")

    rows = []
    for idx in range(len(df)):
        r = df.iloc[idx]
        smi = r[smi_col]
        if pd.isna(smi) or not str(smi).strip():
            continue
        smi = str(smi).strip()
        for col in ratio_cols:
            parsed = parse_ratio_column(col)
            assert parsed is not None
            _, _, frac = parsed
            val = r[col]
            if pd.isna(val):
                continue
            try:
                y = float(val)
            except (TypeError, ValueError):
                try:
                    y = float(str(val).strip())
                except Exception:
                    continue
            rows.append(
                {
                    "smiles": smi,
                    "polar_fraction": float(frac),
                    "rf_obs": y,
                    "ratio_label": str(col),
                    "row_index": idx,
                }
            )
    return pd.DataFrame(rows)


def run_kermt_predict(
    kermt_root: Path,
    checkpoint_dir: Path,
    csv_path: Path,
    npz_path: Path,
    output_csv: Path,
    gpu: int,
    batch_size: int,
) -> None:
    env = os.environ.copy()
    env.setdefault("CUBLAS_WORKSPACE_CONFIG", ":4096:8")
    cmd = [
        sys.executable,
        str(kermt_root / "main.py"),
        "predict",
        "--data_path",
        str(csv_path.resolve()),
        "--features_path",
        str(npz_path.resolve()),
        "--checkpoint_dir",
        str(checkpoint_dir.resolve()),
        "--output_path",
        str(output_csv.resolve()),
        "--gpu",
        str(gpu),
        "--batch_size",
        str(batch_size),
    ]
    subprocess.run(cmd, cwd=str(kermt_root.resolve()), env=env, check=True)


def predict_batch_arrays(
    smiles: list[str],
    polar_fractions: list[float],
    solvent_system: str,
    kermt_root: Path,
    checkpoint_dir: Path,
    src_data_dir: str,
    desc_stats_cache: Path,
    gpu: int,
    batch_size: int,
) -> np.ndarray:
    """返回与 smiles 同顺序的预测 Rf。默认进程内 CUDA 常驻模型（与 c12 optimize_script 同步）。"""
    if len(smiles) != len(polar_fractions):
        raise ValueError("smiles and polar_fractions length mismatch")
    pr = _predictor_keyed(
        kermt_root,
        checkpoint_dir,
        solvent_system,
        src_data_dir,
        desc_stats_cache,
        gpu,
        batch_size,
    )
    points = [
        {"smiles": s, "solvent": _five_vec_from_fraction(fr, solvent_system)}
        for s, fr in zip(smiles, polar_fractions)
    ]
    return pr.predict_points_list(points)


def cmd_single(args: argparse.Namespace) -> None:
    rf = predict_batch_arrays(
        [args.smiles],
        [args.fraction],
        args.system,
        Path(args.kermt_root),
        Path(args.checkpoint_dir),
        args.src_data_dir,
        Path(args.desc_stats_cache),
        args.gpu,
        args.batch_size,
    )[0]
    print(f"predicted_Rf={rf:.6f}")


def cmd_eval_excels(args: argparse.Namespace) -> None:
    import matplotlib.pyplot as plt
    from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score

    out_dir = Path(args.out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    excel_paths = [Path(p) for p in args.excel] if args.excel else DEFAULT_EXCEL_FILES
    summary_lines = []

    for xlsx in excel_paths:
        if not xlsx.is_file():
            print(f"[skip] missing file: {xlsx}", file=sys.stderr)
            continue
        system = _system_from_filename(xlsx)
        df = pd.read_excel(xlsx)
        long_df = excel_long_table(df, system)
        if long_df.empty:
            print(f"[skip] no numeric observations: {xlsx}", file=sys.stderr)
            continue

        n_before = len(long_df)
        long_df = long_df[long_df["smiles"].map(_smiles_ok_for_rdkit)].reset_index(
            drop=True
        )
        n_skip = n_before - len(long_df)
        if n_skip:
            print(
                f"[warn] {xlsx.name}: skipped {n_skip} rows with invalid/empty RDKit SMILES",
                file=sys.stderr,
            )
        if long_df.empty:
            print(f"[skip] no valid SMILES after RDKit filter: {xlsx}", file=sys.stderr)
            continue

        smiles = long_df["smiles"].tolist()
        fracs = long_df["polar_fraction"].tolist()
        y_true = long_df["rf_obs"].values.astype(np.float64)

        y_pred = predict_batch_arrays(
            smiles,
            fracs,
            system,
            Path(args.kermt_root),
            Path(args.checkpoint_dir),
            args.src_data_dir,
            Path(args.desc_stats_cache),
            args.gpu,
            args.batch_size,
        )

        mae = mean_absolute_error(y_true, y_pred)
        rmse = float(np.sqrt(mean_squared_error(y_true, y_pred)))
        r2 = r2_score(y_true, y_pred)
        summary_lines.append(
            f"{xlsx.name}\tN={len(y_true)}\tMAE={mae:.4f}\tRMSE={rmse:.4f}\tR2={r2:.4f}"
        )

        res = long_df.copy()
        res["rf_pred"] = y_pred
        stem = xlsx.stem
        csv_out = out_dir / f"{stem}_kermt_v1_predictions.csv"
        res.to_csv(csv_out, index=False)

        fig, ax = plt.subplots(figsize=(5, 5), dpi=120)
        ax.scatter(y_true, y_pred, alpha=0.35, s=12, edgecolors="none")
        lo = min(y_true.min(), y_pred.min())
        hi = max(y_true.max(), y_pred.max())
        ax.plot([lo, hi], [lo, hi], "k--", lw=1, label="y=x")
        ax.set_xlabel("Observed Rf")
        ax.set_ylabel("Predicted Rf (KERMT Plan A v1)")
        ax.set_title(f"{xlsx.name}\nN={len(y_true)}  MAE={mae:.3f}  R²={r2:.3f}")
        ax.set_aspect("equal", adjustable="box")
        ax.legend(loc="upper left")
        fig.tight_layout()
        fig.savefig(out_dir / f"{stem}_parity.png")
        plt.close(fig)
        print(f"[OK] {xlsx.name} -> {csv_out.name}, parity plot saved.")

    summary_path = out_dir / "summary_metrics.txt"
    summary_path.write_text("\n".join(summary_lines) + "\n", encoding="utf-8")
    print(f"Wrote {summary_path}")


def main():
    ap = argparse.ArgumentParser(description="KERMT Plan A v1 Rf prediction / Excel eval")
    ap.add_argument(
        "--kermt_root",
        type=str,
        default=str(DEFAULT_KERMT_ROOT),
        help="KERMT repository root (default: auto from this script location)",
    )
    ap.add_argument(
        "--checkpoint_dir",
        type=str,
        default=str(DEFAULT_CKPT_DIR),
        help="Directory containing model.pt (single model)",
    )
    ap.add_argument(
        "--src_data_dir",
        type=str,
        default=default_src_data_dir(),
        help="Merged UniMol CSV folder with train_data.csv (for desc z-score)",
    )
    ap.add_argument(
        "--desc_stats_cache",
        type=str,
        default=str(default_desc_stats_cache(_PKG_DIR)),
        help="Cache NPZ for descriptor mean/std",
    )
    ap.add_argument("--gpu", type=int, default=0)
    ap.add_argument("--batch_size", type=int, default=64)

    sub = ap.add_subparsers(dest="cmd", required=True)

    p1 = sub.add_parser("single", help="Predict one (SMILES + system + fraction)")
    p1.add_argument("--smiles", type=str, required=True)
    p1.add_argument(
        "--system",
        type=str,
        required=True,
        help="pe_ea (EA fraction) or dcm_meoh (MeOH fraction)",
    )
    p1.add_argument("--fraction", type=float, required=True)
    p1.set_defaults(func=cmd_single)

    p2 = sub.add_parser("eval-excels", help="Evaluate default or given Excel wide tables")
    p2.add_argument(
        "--excel",
        action="append",
        default=None,
        help="Excel path (repeatable). Default: bundled files under data/",
    )
    p2.add_argument(
        "--out_dir",
        type=str,
        default=str(_PKG_DIR / "data/kermt_v1_eval"),
    )
    p2.set_defaults(func=cmd_eval_excels)

    args = ap.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
